import pygame
import math

from settings import *

from gameplay.ball import Ball
from gameplay.cue import Cue


class Game:

    def __init__(self):

        pygame.init()

        self.screen = pygame.display.set_mode(
            (WIDTH, HEIGHT)
        )

        pygame.display.set_caption(TITLE)

        self.clock = pygame.time.Clock()

        self.running = True

        self.ball = Ball(
            WIDTH // 2,
            HEIGHT // 2,
            WHITE
        )

        self.red_ball = Ball(
            WIDTH // 2 + 200,
            HEIGHT // 2,
            RED
        )

        self.cue = Cue()

    def shoot(self):

        mouse_x, mouse_y = pygame.mouse.get_pos()

        dx = mouse_x - self.ball.x
        dy = mouse_y - self.ball.y

        angle = math.atan2(dy, dx)

        power = 15

        self.ball.vx = math.cos(angle) * power
        self.ball.vy = math.sin(angle) * power

    def collision(self):

        dx = self.red_ball.x - self.ball.x
        dy = self.red_ball.y - self.ball.y

        distance = math.sqrt(dx**2 + dy**2)

        if distance < self.ball.radius + self.red_ball.radius:

            self.red_ball.vx = self.ball.vx
            self.red_ball.vy = self.ball.vy

            self.ball.vx *= -0.3
            self.ball.vy *= -0.3

    def events(self):

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                self.running = False

            if event.type == pygame.MOUSEBUTTONDOWN:

                if self.ball.vx == 0 and self.ball.vy == 0:
                    self.shoot()

    def update(self):

        self.ball.update()
        self.red_ball.update()

        self.collision()

    def draw_table(self):

        self.screen.fill(GREEN)

        pygame.draw.rect(
            self.screen,
            BROWN,
            (40, 40, WIDTH - 80, HEIGHT - 80),
            20
        )

    def draw(self):

        self.draw_table()

        self.ball.draw(self.screen)
        self.red_ball.draw(self.screen)

        if self.ball.vx == 0 and self.ball.vy == 0:

            self.cue.draw(
                self.screen,
                self.ball.x,
                self.ball.y
            )

        pygame.display.flip()

    def run(self):

        while self.running:

            self.clock.tick(FPS)

            self.events()

            self.update()

            self.draw()

        pygame.quit()