WIDTH = 1280
HEIGHT = 720

FPS = 60

TITLE = "Sinuca Python"

TABLE_FRICTION = 0.99

BALL_RADIUS = 15

GREEN = (20, 120, 20)

WHITE = (255, 255, 255)

RED = (220, 50, 50)

BLACK = (0, 0, 0)

BROWN = (90, 40, 20)