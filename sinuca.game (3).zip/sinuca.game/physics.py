from __future__ import annotations

import math
from dataclasses import dataclass, field

import pygame
from pygame.math import Vector2

from config import (
    BALL_COLORS,
    BALL_RADIUS,
    BALL_RESTITUTION,
    BLACK,
    CUE_BALL_START,
    FELT_DARK,
    POCKET_RADIUS,
    RACK_SPOT,
    RAIL_RESTITUTION,
    STOP_SPEED,
    TABLE_FRICTION,
    TABLE_RECT,
    WHITE,
)


@dataclass
class Ball:
    number: int
    pos: Vector2
    color: tuple[int, int, int]
    stripe: bool = False
    is_cue: bool = False
    radius: int = BALL_RADIUS
    vel: Vector2 = field(default_factory=Vector2)
    active: bool = True
    pocketed: bool = False

    def is_moving(self) -> bool:
        return self.active and self.vel.length_squared() > STOP_SPEED * STOP_SPEED

    def stop(self) -> None:
        self.vel.update(0, 0)

    def update(self, dt: float) -> None:
        if not self.active:
            return

        self.pos += self.vel * dt
        self.vel *= TABLE_FRICTION ** (dt * 60.0)

        if self.vel.length_squared() < STOP_SPEED * STOP_SPEED:
            self.stop()

    def draw(self, screen: pygame.Surface, number_font: pygame.font.Font) -> None:
        if not self.active:
            return

        center = (int(self.pos.x), int(self.pos.y))
        shadow_rect = pygame.Rect(0, 0, self.radius * 2, self.radius)
        shadow_rect.center = (center[0] + 3, center[1] + self.radius - 2)
        pygame.draw.ellipse(screen, (0, 0, 0, 90), shadow_rect)

        pygame.draw.circle(screen, self.color, center, self.radius)
        pygame.draw.circle(screen, (255, 255, 255), center, self.radius, 2)

        if self.stripe:
            stripe_rect = pygame.Rect(0, 0, self.radius * 2 - 3, self.radius)
            stripe_rect.center = center
            clip = screen.get_clip()
            mask_rect = pygame.Rect(0, 0, self.radius * 2, self.radius * 2)
            mask_rect.center = center
            screen.set_clip(mask_rect)
            pygame.draw.ellipse(screen, WHITE, stripe_rect)
            screen.set_clip(clip)
            pygame.draw.circle(screen, self.color, center, self.radius // 2)

        if not self.is_cue:
            badge_color = WHITE if self.number != 8 else (230, 230, 220)
            pygame.draw.circle(screen, badge_color, center, max(6, self.radius // 2))
            text_color = BLACK
            text = number_font.render(str(self.number), True, text_color)
            text_rect = text.get_rect(center=center)
            screen.blit(text, text_rect)


class PhysicsWorld:
    def __init__(self) -> None:
        self.table = pygame.Rect(TABLE_RECT)
        self.pockets = self._build_pockets()
        self.pocketed_this_step: list[Ball] = []

    def _build_pockets(self) -> list[Vector2]:
        left = self.table.left
        right = self.table.right
        top = self.table.top
        bottom = self.table.bottom
        mid_x = self.table.centerx
        return [
            Vector2(left, top),
            Vector2(mid_x, top),
            Vector2(right, top),
            Vector2(left, bottom),
            Vector2(mid_x, bottom),
            Vector2(right, bottom),
        ]

    def update(self, balls: list[Ball], dt: float) -> None:
        self.pocketed_this_step.clear()
        max_speed = max((ball.vel.length() for ball in balls if ball.active), default=0)
        substeps = max(1, min(6, math.ceil(max_speed * dt / (BALL_RADIUS * 0.8))))
        step = dt / substeps

        for _ in range(substeps):
            for ball in balls:
                ball.update(step)
                self._check_pockets(ball)
                self._apply_rail_collision(ball)
                self._check_pockets(ball)

            self._resolve_ball_collisions(balls)

    def _apply_rail_collision(self, ball: Ball) -> None:
        if not ball.active:
            return

        if ball.pos.x - ball.radius < self.table.left:
            ball.pos.x = self.table.left + ball.radius
            ball.vel.x = abs(ball.vel.x) * RAIL_RESTITUTION
        elif ball.pos.x + ball.radius > self.table.right:
            ball.pos.x = self.table.right - ball.radius
            ball.vel.x = -abs(ball.vel.x) * RAIL_RESTITUTION

        if ball.pos.y - ball.radius < self.table.top:
            ball.pos.y = self.table.top + ball.radius
            ball.vel.y = abs(ball.vel.y) * RAIL_RESTITUTION
        elif ball.pos.y + ball.radius > self.table.bottom:
            ball.pos.y = self.table.bottom - ball.radius
            ball.vel.y = -abs(ball.vel.y) * RAIL_RESTITUTION

    def _check_pockets(self, ball: Ball) -> None:
        if not ball.active:
            return

        for pocket in self.pockets:
            if ball.pos.distance_to(pocket) <= POCKET_RADIUS:
                self._pocket_ball(ball)
                break

    def _pocket_ball(self, ball: Ball) -> None:
        ball.active = False
        ball.pocketed = True
        ball.stop()
        self.pocketed_this_step.append(ball)

    def _resolve_ball_collisions(self, balls: list[Ball]) -> None:
        active_balls = [ball for ball in balls if ball.active]

        for index, first in enumerate(active_balls):
            for second in active_balls[index + 1 :]:
                delta = second.pos - first.pos
                distance = delta.length()
                min_distance = first.radius + second.radius

                if distance == 0:
                    delta = Vector2(1, 0)
                    distance = 1

                if distance >= min_distance:
                    continue

                normal = delta / distance
                overlap = min_distance - distance
                first.pos -= normal * (overlap / 2)
                second.pos += normal * (overlap / 2)

                relative_velocity = first.vel - second.vel
                speed = relative_velocity.dot(normal)
                if speed <= 0:
                    continue

                impulse = normal * speed * BALL_RESTITUTION
                first.vel -= impulse
                second.vel += impulse

    def draw_pockets(self, screen: pygame.Surface) -> None:
        for pocket in self.pockets:
            pygame.draw.circle(screen, BLACK, (int(pocket.x), int(pocket.y)), POCKET_RADIUS)
            pygame.draw.circle(
                screen,
                FELT_DARK,
                (int(pocket.x), int(pocket.y)),
                POCKET_RADIUS,
                3,
            )


def create_rack() -> list[Ball]:
    balls = [
        Ball(
            number=0,
            pos=Vector2(CUE_BALL_START),
            color=WHITE,
            is_cue=True,
        )
    ]

    order = [1, 9, 2, 10, 8, 3, 11, 4, 12, 5, 13, 6, 14, 7, 15]
    spacing = BALL_RADIUS * 2.08
    start = Vector2(RACK_SPOT)
    cursor = 0

    for row in range(5):
        x = start.x + row * spacing
        y_start = start.y - (row * spacing / 2)
        for col in range(row + 1):
            number = order[cursor]
            cursor += 1
            balls.append(
                Ball(
                    number=number,
                    pos=Vector2(x, y_start + col * spacing),
                    color=BALL_COLORS[number],
                    stripe=number >= 9,
                )
            )

    return balls


def all_stopped(balls: list[Ball]) -> bool:
    return all(not ball.is_moving() for ball in balls)


def active_object_balls(balls: list[Ball]) -> list[Ball]:
    return [ball for ball in balls if ball.active and not ball.is_cue]
