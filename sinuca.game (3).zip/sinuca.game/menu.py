from __future__ import annotations

from dataclasses import dataclass

import pygame

from config import HEIGHT, TITLE, UI_ACCENT, UI_BG, UI_MUTED, UI_PANEL, UI_TEXT, WIDTH


@dataclass
class Button:
    rect: pygame.Rect
    label: str
    action: str

    def draw(self, screen: pygame.Surface, font: pygame.font.Font) -> None:
        hovered = self.rect.collidepoint(pygame.mouse.get_pos())
        fill = UI_ACCENT if hovered else UI_PANEL
        text_color = UI_BG if hovered else UI_TEXT
        pygame.draw.rect(screen, fill, self.rect, border_radius=8)
        pygame.draw.rect(screen, UI_ACCENT, self.rect, 2, border_radius=8)
        label = font.render(self.label, True, text_color)
        screen.blit(label, label.get_rect(center=self.rect.center))


class Menu:
    def __init__(self) -> None:
        self.title_font = pygame.font.Font(None, 84)
        self.subtitle_font = pygame.font.Font(None, 30)
        self.button_font = pygame.font.Font(None, 38)

    def handle_event(self, event: pygame.event.Event, buttons: list[Button]) -> str | None:
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return None

        for button in buttons:
            if button.rect.collidepoint(event.pos):
                return button.action

        return None

    def main_buttons(self) -> list[Button]:
        return self._buttons(
            [
                ("Jogar vs Bot", "bot"),
                ("Pratica", "practice"),
                ("Opções", "options"),
                ("Sair", "quit"),
            ]
        )

    def pause_buttons(self) -> list[Button]:
        return self._buttons(
            [
                ("Continuar", "resume"),
                ("Reiniciar", "restart"),
                ("Opções", "options"),
                ("Menu", "menu"),
            ]
        )

    def game_over_buttons(self) -> list[Button]:
        return self._buttons(
            [
                ("Jogar de novo", "restart"),
                ("Menu", "menu"),
                ("Sair", "quit"),
            ]
        )

    def draw_main(self, screen: pygame.Surface) -> list[Button]:
        self._background(screen)
        title = self.title_font.render(TITLE, True, UI_TEXT)
        subtitle = self.subtitle_font.render("Mesa cheia, tacada limpa, placar direto.", True, UI_MUTED)
        screen.blit(title, title.get_rect(center=(WIDTH // 2, 190)))
        screen.blit(subtitle, subtitle.get_rect(center=(WIDTH // 2, 246)))
        buttons = self.main_buttons()
        for button in buttons:
            button.draw(screen, self.button_font)
        return buttons

    def draw_pause(self, screen: pygame.Surface) -> list[Button]:
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 150))
        screen.blit(overlay, (0, 0))
        title = self.title_font.render("Pausa", True, UI_TEXT)
        screen.blit(title, title.get_rect(center=(WIDTH // 2, 190)))
        buttons = self.pause_buttons()
        for button in buttons:
            button.draw(screen, self.button_font)
        return buttons

    def draw_game_over(self, screen: pygame.Surface, winner_text: str) -> list[Button]:
        self._background(screen)
        title = self.title_font.render("Fim de jogo", True, UI_TEXT)
        winner = self.subtitle_font.render(winner_text, True, UI_ACCENT)
        screen.blit(title, title.get_rect(center=(WIDTH // 2, 180)))
        screen.blit(winner, winner.get_rect(center=(WIDTH // 2, 245)))
        buttons = self.game_over_buttons()
        for button in buttons:
            button.draw(screen, self.button_font)
        return buttons

    def draw_options(self, screen: pygame.Surface, config: dict) -> list[Button]:
        self._background(screen)
        title = self.title_font.render("Opções", True, UI_TEXT)
        screen.blit(title, title.get_rect(center=(WIDTH // 2, 150)))

        volume = int(round(config["music_volume"] * 100))
        difficulty = config["bot_difficulty"]
        buttons = self.options_buttons()

        self._draw_option_label(screen, "Música", f"{volume}%", 255)
        self._draw_volume_bar(screen, config["music_volume"], 305)
        self._draw_option_label(screen, "Bot", difficulty, 380)

        for button in buttons:
            button.draw(screen, self.button_font)

        return buttons

    def options_buttons(self) -> list[Button]:
        buttons = []
        buttons.extend(self._row_buttons(305, [("-", "volume_down"), ("+", "volume_up")]))
        buttons.extend(self._row_buttons(380, [("<", "difficulty_prev"), (">", "difficulty_next")]))

        rect = pygame.Rect(0, 0, 250, 58)
        rect.center = (WIDTH // 2, 500)
        buttons.append(Button(rect=rect, label="Voltar", action="options_back"))
        return buttons

    def _buttons(
        self,
        labels: list[tuple[str, str]],
        start_y: int = 315,
        width: int = 250,
    ) -> list[Button]:
        height = 58
        gap = 18
        buttons = []
        for index, (label, action) in enumerate(labels):
            rect = pygame.Rect(0, 0, width, height)
            rect.center = (WIDTH // 2, start_y + index * (height + gap))
            buttons.append(Button(rect=rect, label=label, action=action))
        return buttons

    def _row_buttons(self, y: int, labels: list[tuple[str, str]]) -> list[Button]:
        buttons = []
        for x, (label, action) in zip((WIDTH // 2 - 185, WIDTH // 2 + 185), labels):
            rect = pygame.Rect(0, 0, 58, 48)
            rect.center = (x, y)
            buttons.append(Button(rect=rect, label=label, action=action))
        return buttons

    def _draw_option_label(self, screen: pygame.Surface, label: str, value: str, y: int) -> None:
        label_surface = self.subtitle_font.render(label, True, UI_MUTED)
        value_surface = self.button_font.render(value, True, UI_TEXT)
        screen.blit(label_surface, label_surface.get_rect(center=(WIDTH // 2, y - 36)))
        screen.blit(value_surface, value_surface.get_rect(center=(WIDTH // 2, y)))

    def _draw_volume_bar(self, screen: pygame.Surface, volume: float, y: int) -> None:
        track = pygame.Rect(0, 0, 240, 12)
        track.center = (WIDTH // 2, y + 35)
        pygame.draw.rect(screen, UI_PANEL, track, border_radius=6)
        fill = track.copy()
        fill.width = int(track.width * max(0.0, min(1.0, volume)))
        pygame.draw.rect(screen, UI_ACCENT, fill, border_radius=6)

    def _background(self, screen: pygame.Surface) -> None:
        screen.fill(UI_BG)
        for y in range(0, HEIGHT, 18):
            color = (22, 30, 34) if y % 36 == 0 else (18, 25, 29)
            pygame.draw.line(screen, color, (0, y), (WIDTH, y))
