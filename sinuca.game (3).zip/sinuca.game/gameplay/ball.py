import pygame
from settings import *


class Ball:

    def __init__(self, x, y, color):

        self.x = x
        self.y = y

        self.radius = BALL_RADIUS

        self.color = color

        self.vx = 0
        self.vy = 0

    def update(self):

        self.x += self.vx
        self.y += self.vy

        self.vx *= TABLE_FRICTION
        self.vy *= TABLE_FRICTION

        if abs(self.vx) < 0.01:
            self.vx = 0

        if abs(self.vy) < 0.01:
            self.vy = 0

    def draw(self, screen):

        pygame.draw.circle(
            screen,
            self.color,
            (int(self.x), int(self.y)),
            self.radius
        )