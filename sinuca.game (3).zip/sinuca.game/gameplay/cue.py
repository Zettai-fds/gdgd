import pygame
import math

from settings import *


class Cue:

    def draw(self, screen, ball_x, ball_y):

        mouse_x, mouse_y = pygame.mouse.get_pos()

        angle = math.atan2(
            mouse_y - ball_y,
            mouse_x - ball_x
        )

        length = 120

        end_x = ball_x - math.cos(angle) * length
        end_y = ball_y - math.sin(angle) * length

        pygame.draw.line(
            screen,
            BROWN,
            (ball_x, ball_y),
            (end_x, end_y),
            5
        )