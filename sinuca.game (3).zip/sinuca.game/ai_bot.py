from __future__ import annotations

import random
from dataclasses import dataclass

from pygame.math import Vector2

from config import BALL_RADIUS, DIFFICULTY_LEVELS, MAX_POWER, clamp
from physics import Ball, active_object_balls


@dataclass
class ShotPlan:
    direction: Vector2
    power: float
    target_number: int | None = None


@dataclass
class ShotCandidate:
    target: Ball
    pocket: Vector2
    ghost_ball: Vector2
    cue_distance: float
    pocket_distance: float
    score: float
    blocked: bool


class BotAI:
    def __init__(self, difficulty: str = "Médio") -> None:
        self.set_difficulty(difficulty)

    def set_difficulty(self, difficulty: str) -> None:
        if difficulty not in DIFFICULTY_LEVELS:
            difficulty = "Médio"

        self.difficulty = difficulty
        self.profile = DIFFICULTY_LEVELS[difficulty]

    def pick_shot(self, cue_ball: Ball, balls: list[Ball], pockets: list[Vector2]) -> ShotPlan:
        candidates = self._build_candidates(cue_ball, balls, pockets)
        if not candidates:
            return ShotPlan(Vector2(1, 0), 0, None)

        best = min(candidates, key=lambda candidate: candidate.score)
        aim = best.ghost_ball - cue_ball.pos

        if aim.length_squared() <= 1:
            aim = best.target.pos - cue_ball.pos

        direction = aim.normalize()
        power = self._ideal_power(best)
        direction, power = self._apply_difficulty_error(direction, power, best)

        return ShotPlan(direction=direction, power=power, target_number=best.target.number)

    def _build_candidates(
        self,
        cue_ball: Ball,
        balls: list[Ball],
        pockets: list[Vector2],
    ) -> list[ShotCandidate]:
        candidates = []

        for target in active_object_balls(balls):
            for pocket in pockets:
                to_pocket = pocket - target.pos
                if to_pocket.length_squared() <= 1:
                    continue

                pocket_direction = to_pocket.normalize()
                ghost_ball = target.pos - pocket_direction * (BALL_RADIUS * 2.12)
                cue_vector = ghost_ball - cue_ball.pos
                if cue_vector.length_squared() <= 1:
                    continue

                cue_clear = self._path_is_clear(cue_ball.pos, ghost_ball, balls, {cue_ball.number, target.number})
                pocket_clear = self._path_is_clear(target.pos, pocket, balls, {cue_ball.number, target.number})
                blocked = not cue_clear or not pocket_clear
                cue_distance = cue_ball.pos.distance_to(ghost_ball)
                pocket_distance = target.pos.distance_to(pocket)

                score = cue_distance * 0.72 + pocket_distance
                if blocked:
                    score += self.profile["block_penalty"]
                if target.number == 8:
                    score += 110.0

                candidates.append(
                    ShotCandidate(
                        target=target,
                        pocket=pocket,
                        ghost_ball=ghost_ball,
                        cue_distance=cue_distance,
                        pocket_distance=pocket_distance,
                        score=score,
                        blocked=blocked,
                    )
                )

        return candidates

    def _ideal_power(self, candidate: ShotCandidate) -> float:
        # Distances are in pixels; this keeps the shot strong without turning every hit into a break.
        power = 320.0 + candidate.cue_distance * 2.15 + candidate.pocket_distance * 1.05
        if candidate.blocked:
            power += 90.0
        return clamp(power, 430.0, MAX_POWER * 0.94)

    def _apply_difficulty_error(
        self,
        direction: Vector2,
        power: float,
        candidate: ShotCandidate,
    ) -> tuple[Vector2, float]:
        if self.difficulty == "Difícil":
            return direction, power

        distance_factor = clamp(candidate.cue_distance / 650.0, 0.0, 1.0)
        angle_error = self.profile["angle_error"] * (1.0 + distance_factor * 0.55)
        power_error = self.profile["power_error"] * (1.0 + distance_factor * 0.35)

        direction = direction.rotate(random.uniform(-angle_error, angle_error))
        power *= random.uniform(1.0 - power_error, 1.0 + power_error)
        return direction, clamp(power, 250.0, MAX_POWER)

    def _path_is_clear(
        self,
        start: Vector2,
        end: Vector2,
        balls: list[Ball],
        ignored_numbers: set[int],
    ) -> bool:
        for ball in balls:
            if not ball.active or ball.number in ignored_numbers:
                continue

            distance = self._distance_to_segment(ball.pos, start, end)
            if distance < BALL_RADIUS * 2.05:
                return False

        return True

    def _distance_to_segment(self, point: Vector2, start: Vector2, end: Vector2) -> float:
        segment = end - start
        if segment.length_squared() <= 1:
            return point.distance_to(start)

        t = (point - start).dot(segment) / segment.length_squared()
        projection = start + segment * clamp(t, 0.0, 1.0)
        return point.distance_to(projection)
