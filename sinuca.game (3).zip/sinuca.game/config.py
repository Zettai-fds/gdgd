import json
from pathlib import Path


WIDTH = 1280
HEIGHT = 720
FPS = 60
TITLE = "Sinuca Python"

BASE_DIR = Path(__file__).resolve().parent
ASSETS_DIR = BASE_DIR / "assets"
IMAGES_DIR = ASSETS_DIR / "images"
SOUNDS_DIR = ASSETS_DIR / "sounds"
CONFIG_FILE = ASSETS_DIR / "config.json"
MUSIC_EXTENSIONS = (".ogg", ".mp3", ".wav")

TABLE_RECT = (80, 70, 1120, 560)
RAIL_WIDTH = 34
BALL_RADIUS = 14
POCKET_RADIUS = 31

CUE_BALL_START = (330, 360)
RACK_SPOT = (820, 360)

TABLE_FRICTION = 0.985
BALL_RESTITUTION = 0.96
RAIL_RESTITUTION = 0.78
STOP_SPEED = 7.0
MAX_POWER = 1450.0
POWER_SCALE = 6.2
BOT_THINK_TIME = 850

FELT = (25, 116, 72)
FELT_DARK = (14, 74, 48)
FELT_LIGHT = (47, 151, 93)
WOOD = (99, 51, 26)
WOOD_LIGHT = (144, 82, 42)
BROWN = WOOD
POCKET = (13, 12, 13)
WHITE = (242, 239, 224)
BLACK = (20, 19, 18)
RED = (205, 47, 47)
YELLOW = (239, 198, 71)
BLUE = (44, 91, 204)
PURPLE = (114, 69, 158)
ORANGE = (224, 121, 42)
GREEN = (42, 148, 76)
MAROON = (137, 40, 48)
UI_BG = (18, 23, 27)
UI_PANEL = (31, 39, 45)
UI_TEXT = (235, 238, 232)
UI_MUTED = (164, 174, 168)
UI_ACCENT = (236, 183, 76)

BALL_COLORS = {
    1: YELLOW,
    2: BLUE,
    3: RED,
    4: PURPLE,
    5: ORANGE,
    6: GREEN,
    7: MAROON,
    8: BLACK,
    9: YELLOW,
    10: BLUE,
    11: RED,
    12: PURPLE,
    13: ORANGE,
    14: GREEN,
    15: MAROON,
}

DIFFICULTY_LEVELS = {
    "Fácil": {
        "angle_error": 12.0,
        "power_error": 0.24,
        "block_penalty": 250.0,
    },
    "Médio": {
        "angle_error": 4.0,
        "power_error": 0.09,
        "block_penalty": 1350.0,
    },
    "Difícil": {
        "angle_error": 0.0,
        "power_error": 0.0,
        "block_penalty": 6500.0,
    },
}
DIFFICULTY_ORDER = tuple(DIFFICULTY_LEVELS.keys())

DEFAULT_USER_CONFIG = {
    "music_volume": 0.7,
    "music_file": "background.ogg",
    "bot_difficulty": "Médio",
    "show_guides": True,
}


def clamp(value, minimum, maximum):
    return max(minimum, min(maximum, value))


def normalize_user_config(data):
    """Return a complete config dict, accepting old save-file keys too."""
    config = DEFAULT_USER_CONFIG.copy()

    if not isinstance(data, dict):
        return config

    if "volume" in data and "music_volume" not in data:
        data["music_volume"] = data["volume"]

    if "bot_skill" in data and "bot_difficulty" not in data:
        try:
            skill = float(data["bot_skill"])
        except (TypeError, ValueError):
            skill = 0.68
        if skill < 0.55:
            data["bot_difficulty"] = "Fácil"
        elif skill > 0.82:
            data["bot_difficulty"] = "Difícil"
        else:
            data["bot_difficulty"] = "Médio"

    try:
        volume = float(data.get("music_volume", config["music_volume"]))
    except (TypeError, ValueError):
        volume = config["music_volume"]

    config["music_volume"] = clamp(volume, 0.0, 1.0)
    config["show_guides"] = bool(data.get("show_guides", config["show_guides"]))

    music_file = data.get("music_file", config["music_file"])
    if isinstance(music_file, str) and music_file.strip():
        config["music_file"] = music_file.strip()

    difficulty = data.get("bot_difficulty", config["bot_difficulty"])
    if difficulty in DIFFICULTY_LEVELS:
        config["bot_difficulty"] = difficulty

    return config


def load_user_config():
    if not CONFIG_FILE.exists():
        return DEFAULT_USER_CONFIG.copy()

    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return DEFAULT_USER_CONFIG.copy()

    return normalize_user_config(data)


def save_user_config(data):
    ASSETS_DIR.mkdir(parents=True, exist_ok=True)
    config = normalize_user_config(data)
    CONFIG_FILE.write_text(
        json.dumps(config, indent=2, ensure_ascii=True),
        encoding="utf-8",
    )
    return config


def find_background_music(configured_file=None):
    """Find the first playable music file inside assets/sounds."""
    if not SOUNDS_DIR.exists():
        return None

    if configured_file:
        candidate = SOUNDS_DIR / configured_file
        if candidate.exists() and candidate.suffix.lower() in MUSIC_EXTENSIONS:
            return candidate

    preferred_names = ("background", "music", "theme", "tema")
    for name in preferred_names:
        for extension in MUSIC_EXTENSIONS:
            candidate = SOUNDS_DIR / f"{name}{extension}"
            if candidate.exists():
                return candidate

    for candidate in sorted(SOUNDS_DIR.iterdir()):
        if candidate.suffix.lower() in MUSIC_EXTENSIONS:
            return candidate

    return None
