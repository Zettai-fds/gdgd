Coloque a musica de fundo aqui.

O pygame.mixer nao toca links do YouTube diretamente. Ele precisa de um arquivo local.

Para usar a musica indicada pelo link:
1. Obtenha o audio apenas se voce tiver permissao para usar essa musica.
2. Converta/salve o arquivo como background.ogg, background.mp3 ou background.wav.
3. Coloque o arquivo nesta pasta: assets/sounds/
4. Se usar outro nome, altere music_file em assets/config.json.

Link de referencia informado:
https://www.youtube.com/live/PaFHwTjy1yE?si=jPJAuXExN2yPaqvY
