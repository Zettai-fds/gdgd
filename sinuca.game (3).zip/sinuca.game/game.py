from __future__ import annotations

import pygame
from pygame.math import Vector2

from ai_bot import BotAI
from config import (
    BALL_RADIUS,
    BOT_THINK_TIME,
    CUE_BALL_START,
    DIFFICULTY_ORDER,
    FELT,
    FELT_DARK,
    FELT_LIGHT,
    FPS,
    HEIGHT,
    MAX_POWER,
    POWER_SCALE,
    RAIL_WIDTH,
    TABLE_RECT,
    TITLE,
    UI_ACCENT,
    UI_BG,
    UI_MUTED,
    UI_PANEL,
    UI_TEXT,
    WHITE,
    WIDTH,
    WOOD,
    WOOD_LIGHT,
    clamp,
    find_background_music,
    load_user_config,
    save_user_config,
)
from menu import Menu
from physics import Ball, PhysicsWorld, active_object_balls, all_stopped, create_rack


class Game:
    def __init__(self) -> None:
        pygame.mixer.pre_init(44100, -16, 2, 512)
        pygame.init()
        pygame.display.set_caption(TITLE)
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 28)
        self.small_font = pygame.font.Font(None, 22)
        self.number_font = pygame.font.Font(None, 16)
        self.menu = Menu()
        self.user_config = load_user_config()
        self.bot = BotAI(self.user_config["bot_difficulty"])
        self.music_loaded = False
        self._start_background_music()

        self.running = True
        self.state = "menu"
        self.mode = "bot"
        self.options_return_state = "menu"
        self.buttons = []
        self.world = PhysicsWorld()
        self.balls: list[Ball] = []
        self.cue_ball: Ball | None = None
        self.current_turn = "player"
        self.scores = {"player": 0, "bot": 0}
        self.aiming = False
        self.shot_active = False
        self.shot_owner = "player"
        self.pocketed_since_shot: list[int] = []
        self.scratched_this_shot = False
        self.bot_started_waiting_at: int | None = None
        self.winner_text = ""

    def new_match(self, mode: str) -> None:
        self.mode = mode
        self.state = "playing"
        self.bot.set_difficulty(self.user_config["bot_difficulty"])
        self.world = PhysicsWorld()
        self.balls = create_rack()
        self.cue_ball = self.balls[0]
        self.current_turn = "player"
        self.scores = {"player": 0, "bot": 0}
        self.aiming = False
        self.shot_active = False
        self.pocketed_since_shot.clear()
        self.scratched_this_shot = False
        self.bot_started_waiting_at = None
        self.winner_text = ""

    def run(self) -> None:
        while self.running:
            dt = self.clock.tick(FPS) / 1000.0
            self.events()
            self.update(dt)
            self.draw()

        pygame.quit()

    def events(self) -> None:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
                continue

            if self.state == "menu":
                self._handle_menu_event(event)
            elif self.state == "options":
                self._handle_options_event(event)
            elif self.state == "pause":
                self._handle_pause_event(event)
            elif self.state == "game_over":
                self._handle_game_over_event(event)
            elif self.state == "playing":
                self._handle_playing_event(event)

    def _handle_menu_event(self, event: pygame.event.Event) -> None:
        action = self.menu.handle_event(event, self.buttons)
        if action == "bot":
            self.new_match("bot")
        elif action == "practice":
            self.new_match("practice")
        elif action == "options":
            self._open_options("menu")
        elif action == "quit":
            self.running = False

    def _handle_pause_event(self, event: pygame.event.Event) -> None:
        action = self.menu.handle_event(event, self.buttons)
        if action == "resume":
            self.state = "playing"
        elif action == "restart":
            self.new_match(self.mode)
        elif action == "options":
            self._open_options("pause")
        elif action == "menu":
            self.state = "menu"

    def _handle_options_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.state = self.options_return_state
            return

        action = self.menu.handle_event(event, self.buttons)
        if action == "volume_down":
            self._change_music_volume(-0.05)
        elif action == "volume_up":
            self._change_music_volume(0.05)
        elif action == "difficulty_prev":
            self._cycle_bot_difficulty(-1)
        elif action == "difficulty_next":
            self._cycle_bot_difficulty(1)
        elif action == "options_back":
            self.state = self.options_return_state

    def _handle_game_over_event(self, event: pygame.event.Event) -> None:
        action = self.menu.handle_event(event, self.buttons)
        if action == "restart":
            self.new_match(self.mode)
        elif action == "menu":
            self.state = "menu"
        elif action == "quit":
            self.running = False

    def _handle_playing_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.state = "pause"
            elif event.key == pygame.K_r:
                self.new_match(self.mode)

        if not self._human_can_shoot():
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.aiming = True
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.aiming:
            self.aiming = False
            self._shoot_from_mouse()

    def update(self, dt: float) -> None:
        if self.state != "playing":
            return

        self.world.update(self.balls, dt)
        self._collect_pocketed()

        if self.shot_active and all_stopped(self.balls):
            self._finish_turn()

        if self.state == "playing" and self._bot_can_shoot():
            self._update_bot_turn()

    def draw(self) -> None:
        if self.state == "menu":
            self.buttons = self.menu.draw_main(self.screen)
        elif self.state == "options":
            self.buttons = self.menu.draw_options(self.screen, self.user_config)
        else:
            self._draw_game()
            if self.state == "pause":
                self.buttons = self.menu.draw_pause(self.screen)
            elif self.state == "game_over":
                self.buttons = self.menu.draw_game_over(self.screen, self.winner_text)

        pygame.display.flip()

    def _draw_game(self) -> None:
        self.screen.fill(UI_BG)
        self._draw_table()
        self._draw_aiming_overlay()

        for ball in self.balls:
            ball.draw(self.screen, self.number_font)

        self._draw_hud()

    def _draw_table(self) -> None:
        table = pygame.Rect(TABLE_RECT)
        rail = table.inflate(RAIL_WIDTH * 2, RAIL_WIDTH * 2)
        shadow = rail.move(0, 12)

        pygame.draw.rect(self.screen, (0, 0, 0), shadow, border_radius=42)
        pygame.draw.rect(self.screen, WOOD, rail, border_radius=42)
        pygame.draw.rect(self.screen, WOOD_LIGHT, rail, 6, border_radius=42)
        pygame.draw.rect(self.screen, FELT_DARK, table.inflate(10, 10), border_radius=26)
        pygame.draw.rect(self.screen, FELT, table, border_radius=24)

        for x in range(table.left + 90, table.right, 140):
            pygame.draw.circle(self.screen, FELT_LIGHT, (x, table.top + 18), 3)
            pygame.draw.circle(self.screen, FELT_LIGHT, (x, table.bottom - 18), 3)

        for y in range(table.top + 90, table.bottom, 140):
            pygame.draw.circle(self.screen, FELT_LIGHT, (table.left + 18, y), 3)
            pygame.draw.circle(self.screen, FELT_LIGHT, (table.right - 18, y), 3)

        self.world.draw_pockets(self.screen)

    def _draw_aiming_overlay(self) -> None:
        if not self._human_can_shoot() or self.cue_ball is None:
            return

        mouse = Vector2(pygame.mouse.get_pos())
        cue = self.cue_ball.pos
        direction = mouse - cue

        if direction.length_squared() <= 4:
            return

        direction = direction.normalize()
        distance = min(mouse.distance_to(cue), MAX_POWER / POWER_SCALE)
        guide_end = cue + direction * 320
        cue_back = cue - direction * (72 + distance * 0.35)
        cue_tip = cue - direction * (BALL_RADIUS + 8)

        if self.user_config["show_guides"]:
            pygame.draw.line(
                self.screen,
                (235, 238, 232),
                (int(cue.x), int(cue.y)),
                (int(guide_end.x), int(guide_end.y)),
                2,
            )

        pygame.draw.line(
            self.screen,
            WOOD_LIGHT,
            (int(cue_back.x), int(cue_back.y)),
            (int(cue_tip.x), int(cue_tip.y)),
            7,
        )
        pygame.draw.line(
            self.screen,
            (230, 214, 166),
            (int(cue_back.x), int(cue_back.y)),
            (int(cue_tip.x), int(cue_tip.y)),
            2,
        )

        if self.aiming:
            self._draw_power_meter(distance * POWER_SCALE / MAX_POWER)

    def _draw_power_meter(self, fraction: float) -> None:
        fraction = max(0.0, min(1.0, fraction))
        rect = pygame.Rect(0, 0, 260, 14)
        rect.center = (WIDTH // 2, HEIGHT - 38)
        pygame.draw.rect(self.screen, UI_PANEL, rect, border_radius=7)
        fill = rect.copy()
        fill.width = int(rect.width * fraction)
        pygame.draw.rect(self.screen, UI_ACCENT, fill, border_radius=7)

    def _draw_hud(self) -> None:
        pygame.draw.rect(self.screen, UI_PANEL, (0, 0, WIDTH, 52))
        turn_label = "Sua vez" if self.current_turn == "player" else "Bot"
        if self.mode == "practice":
            turn_label = "Pratica"

        left = self.font.render(f"{turn_label}", True, UI_TEXT)
        score = self.font.render(
            f"Voce {self.scores['player']}  |  Bot {self.scores['bot']}",
            True,
            UI_TEXT,
        )
        remaining = self.small_font.render(
            f"Bolas na mesa: {len(active_object_balls(self.balls))}",
            True,
            UI_MUTED,
        )
        self.screen.blit(left, (24, 15))
        self.screen.blit(score, score.get_rect(center=(WIDTH // 2, 26)))
        self.screen.blit(remaining, remaining.get_rect(midright=(WIDTH - 24, 27)))

    def _open_options(self, return_state: str) -> None:
        self.options_return_state = return_state
        self.state = "options"

    def _change_music_volume(self, delta: float) -> None:
        self.user_config["music_volume"] = clamp(self.user_config["music_volume"] + delta, 0.0, 1.0)
        self.user_config = save_user_config(self.user_config)
        self._apply_music_volume()

    def _cycle_bot_difficulty(self, step: int) -> None:
        current = self.user_config["bot_difficulty"]
        index = DIFFICULTY_ORDER.index(current)
        difficulty = DIFFICULTY_ORDER[(index + step) % len(DIFFICULTY_ORDER)]
        self.user_config["bot_difficulty"] = difficulty
        self.user_config = save_user_config(self.user_config)
        self.bot.set_difficulty(difficulty)

    def _start_background_music(self) -> None:
        music_path = find_background_music(self.user_config.get("music_file"))
        if music_path is None:
            print(
                "Musica nao encontrada. Coloque um arquivo .ogg, .mp3 ou .wav "
                "em assets/sounds/ e configure music_file em assets/config.json."
            )
            return

        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init()
            pygame.mixer.music.load(str(music_path))
            self._apply_music_volume()
            pygame.mixer.music.play(-1)
            self.music_loaded = True
            print(f"Musica carregada: {music_path.name}")
        except pygame.error as error:
            self.music_loaded = False
            print(f"Falha ao carregar musica {music_path}: {error}")

    def _apply_music_volume(self) -> None:
        if pygame.mixer.get_init():
            pygame.mixer.music.set_volume(self.user_config["music_volume"])

    def _human_can_shoot(self) -> bool:
        if self.state != "playing" or self.cue_ball is None:
            return False
        if not all_stopped(self.balls) or self.shot_active:
            return False
        return self.mode == "practice" or self.current_turn == "player"

    def _bot_can_shoot(self) -> bool:
        if self.mode != "bot" or self.current_turn != "bot" or self.cue_ball is None:
            return False
        return all_stopped(self.balls) and not self.shot_active

    def _shoot_from_mouse(self) -> None:
        if self.cue_ball is None:
            return

        mouse = Vector2(pygame.mouse.get_pos())
        direction = mouse - self.cue_ball.pos
        if direction.length_squared() < 25:
            return

        distance = min(direction.length(), MAX_POWER / POWER_SCALE)
        power = max(180.0, min(MAX_POWER, distance * POWER_SCALE))
        self._shoot(direction.normalize(), power, self.current_turn)

    def _shoot(self, direction: Vector2, power: float, owner: str) -> None:
        if self.cue_ball is None or not self.cue_ball.active:
            return

        self.cue_ball.vel = direction.normalize() * power
        self.shot_owner = owner
        self.shot_active = True
        self.pocketed_since_shot.clear()
        self.scratched_this_shot = False
        self.bot_started_waiting_at = None

    def _update_bot_turn(self) -> None:
        now = pygame.time.get_ticks()
        if self.bot_started_waiting_at is None:
            self.bot_started_waiting_at = now
            return

        if now - self.bot_started_waiting_at < BOT_THINK_TIME:
            return

        if self.cue_ball is None or not self.cue_ball.active:
            self._reset_cue_ball()

        plan = self.bot.pick_shot(self.cue_ball, self.balls, self.world.pockets)
        if plan.power > 0:
            self._shoot(plan.direction, plan.power, "bot")

    def _collect_pocketed(self) -> None:
        for ball in self.world.pocketed_this_step:
            if ball.is_cue:
                self.scratched_this_shot = True
            else:
                self.pocketed_since_shot.append(ball.number)

    def _finish_turn(self) -> None:
        self.shot_active = False
        pocketed_count = len(self.pocketed_since_shot)

        if pocketed_count:
            self.scores[self.shot_owner] += pocketed_count

        if self.scratched_this_shot:
            self._reset_cue_ball()
            self._switch_turn()
        elif pocketed_count == 0 and self.mode == "bot":
            self._switch_turn()

        self.pocketed_since_shot.clear()
        self.scratched_this_shot = False
        self.bot_started_waiting_at = None
        self._check_game_over()

    def _switch_turn(self) -> None:
        self.current_turn = "bot" if self.current_turn == "player" else "player"

    def _reset_cue_ball(self) -> None:
        if self.cue_ball is None:
            return

        start = Vector2(CUE_BALL_START)
        candidates = [start]
        for offset in range(1, 7):
            candidates.extend(
                [
                    start + Vector2(offset * BALL_RADIUS * 2, 0),
                    start + Vector2(0, offset * BALL_RADIUS * 2),
                    start + Vector2(0, -offset * BALL_RADIUS * 2),
                ]
            )

        for candidate in candidates:
            if self._position_is_clear(candidate):
                self.cue_ball.pos = candidate
                break
        else:
            self.cue_ball.pos = start

        self.cue_ball.active = True
        self.cue_ball.pocketed = False
        self.cue_ball.stop()

    def _position_is_clear(self, pos: Vector2) -> bool:
        table = pygame.Rect(TABLE_RECT)
        if not table.collidepoint(pos.x, pos.y):
            return False

        for ball in self.balls:
            if ball is self.cue_ball or not ball.active:
                continue
            if ball.pos.distance_to(pos) < BALL_RADIUS * 2.2:
                return False

        return True

    def _check_game_over(self) -> None:
        if active_object_balls(self.balls):
            return

        if self.scores["player"] > self.scores["bot"]:
            self.winner_text = "Voce venceu."
        elif self.scores["bot"] > self.scores["player"]:
            self.winner_text = "Bot venceu."
        else:
            self.winner_text = "Empate."
        self.state = "game_over"
